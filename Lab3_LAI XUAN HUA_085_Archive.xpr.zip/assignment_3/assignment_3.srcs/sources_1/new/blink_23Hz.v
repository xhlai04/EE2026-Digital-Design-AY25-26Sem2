`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 02/14/2026 11:13:00 PM
// Design Name: 
// Module Name: blink_23Hz
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module blink_23Hz(input CLOCK, output reg blink_23Hz = 0);
    reg [21:0] COUNT = 0;
    always @ (posedge CLOCK) begin
        COUNT <= (COUNT >= 2_173_912) ? 0 : COUNT + 1;
        blink_23Hz <= (COUNT == 2_173_912) ? ~ blink_23Hz : blink_23Hz;
    end
endmodule
