`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 02/14/2026 11:18:18 PM
// Design Name: 
// Module Name: blink_5Hz
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module blink_5Hz(input CLOCK, output reg blink_5Hz = 0);
    reg [23:0] COUNT = 0;
    always @ (posedge CLOCK) begin
        COUNT <= (COUNT >= 9_999_999) ? 0 : COUNT + 1;
        blink_5Hz <= (COUNT >= 9_999_999) ? ~blink_5Hz : blink_5Hz;
    end
endmodule
