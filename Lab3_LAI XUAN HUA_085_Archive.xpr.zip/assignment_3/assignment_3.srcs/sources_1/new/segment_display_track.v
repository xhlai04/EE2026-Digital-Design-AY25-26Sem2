`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 02/15/2026 12:56:49 PM
// Design Name: 
// Module Name: segment_display_track
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module segment_display_track(
    input CLOCK, 
    input [4:0] COUNT, //from led_tracker_seq
    input [4:0] BTN,
    output reg [7:0] SEG = 8'b1111_1111,
    output reg [3:0] AN = 4'b1111,
    output reg LD15 = 0);
    
    reg [2:0] STATE = 0; 
    reg [4:0] BTN_REG;
    wire [4:0] BTN_PRESSED = BTN & ~BTN_REG;
    
    always @ (posedge CLOCK) begin
        BTN_REG <= BTN;
        
        case (STATE)
        
        0: begin
            LD15 <= 0;
            AN <= 4'b1111;
            if (COUNT >= 10) 
                STATE <= 1;
            end
        
        1: begin
            SEG <= 8'b1100_1111; //l
            AN <= 4'b1110;
            if (BTN_PRESSED[4] == 1)
                STATE <= 2;
            end
            
        2: begin
            SEG <= 8'b1110_0011; // u
            AN <= 4'b1101;
            if (BTN_PRESSED[1] == 1)
                STATE <= 3;
           end
           
        3: begin
            SEG <= 8'b1010_1111; //r
            AN <= 4'b1011; 
            if (BTN_PRESSED[2] == 1)
                STATE <= 4;
            end
                
        4: begin
            SEG <= 8'b1010_0001; //d
            AN <= 4'b0111;
            if (BTN_PRESSED[3] == 1)
                STATE <= 5;
            end
            
        5: begin 
            SEG <= 8'b1100_1111; //l
            AN <= 4'b1110;   
            LD15 <= 1;
            end
            
       default: STATE <= 0;         
       endcase
    end 
    
endmodule
