`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 02/14/2026 10:07:49 PM
// Design Name: 
// Module Name: clk_0488Hz
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module clk_0488Hz(input CLOCK, output reg clk_0488Hz = 0);
    reg [27:0] COUNT = 0;
    
    always @ (posedge CLOCK) begin
       if (COUNT >= 204_999_999) begin
            COUNT <= 0;
            clk_0488Hz <= 1'b1;
       end else begin
            COUNT <= COUNT + 1;
            clk_0488Hz <= 1'b0;
       end
    end
endmodule
