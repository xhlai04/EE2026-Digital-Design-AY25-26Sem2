`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 02/14/2026 11:30:25 PM
// Design Name: 
// Module Name: led_seq
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module led_seq(input [4:0] COUNT, output reg [9:0] LEDS = 10'b000_000_0000 );
    always @ (*) begin
        case (COUNT) 
            0: LEDS <= 10'b000_000_0000 ;
            1: LEDS <= 10'b000_000_0001;
            2: LEDS <= 10'b000_000_0011;
            3: LEDS <= 10'b000_000_0111;
            4: LEDS <= 10'b000_000_1111;
            5: LEDS <= 10'b000_001_1111;
            6: LEDS <= 10'b000_011_1111;
            7: LEDS <= 10'b000_111_1111;
            8: LEDS <= 10'b001_111_1111;
            9: LEDS <= 10'b011_111_1111;
            10: LEDS <= 10'b111_111_1111;
            default: LEDS <= 10'b000_000_0000;
        endcase
    end
endmodule
