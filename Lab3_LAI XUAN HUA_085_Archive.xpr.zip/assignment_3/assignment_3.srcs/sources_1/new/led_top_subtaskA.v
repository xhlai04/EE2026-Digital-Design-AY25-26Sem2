`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 02/14/2026 11:37:55 PM
// Design Name: 
// Module Name: led_top_subtaskA
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module led_top_subtaskA(
        
        input CLOCK, input SW2, SW3, SW4,input [4:0] BTN, 
        output reg [9:0] LEDS, output [7:0] SEG, output [3:0] AN, output LED15);
        
    wire clk_0488Hz;
    wire blink_025Hz;
    wire blink_5Hz;
    wire blink_23Hz;
    wire clk_50Hz;
    wire [9:0] led_sequence;
    wire [4:0] COUNT;
    
    //led sequence 
    clk_0488Hz fa0 (CLOCK, clk_0488Hz);
    led_tracker_seq fa1 (clk_0488Hz, COUNT);
    led_seq fa2 (COUNT, led_sequence);
    
    //led control frequency
    blink_025Hz fa3 (CLOCK, blink_025Hz);
    blink_5Hz fa4 (CLOCK, blink_5Hz);
    blink_23Hz fa5 (CLOCK, blink_23Hz);
    
    segment_display_track fa6 (CLOCK, COUNT, BTN, SEG, AN, LED15 );
    
    //multiplexer 
    always @(*) begin
        LEDS = led_sequence; //default case
        if (SW4) begin
            LEDS[4] = blink_23Hz;
        end
        else if (SW3) begin
            LEDS[3] = blink_5Hz;
        end
        else if (SW2) begin    
            LEDS[2] = blink_025Hz;
        end
    end
             
endmodule
