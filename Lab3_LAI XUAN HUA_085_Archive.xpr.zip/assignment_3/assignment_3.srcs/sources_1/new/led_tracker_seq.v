`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 02/14/2026 11:27:37 PM
// Design Name: 
// Module Name: led_tracker_seq
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module led_tracker_seq(input clk_0488Hz, output reg [4:0] COUNT = 0);
    always @ (posedge clk_0488Hz) begin
        if (COUNT < 10) begin
            COUNT <= COUNT + 1;
        end else begin
            COUNT <= 10;
        end
    end
endmodule
