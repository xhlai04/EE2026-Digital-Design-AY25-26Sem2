`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 02/14/2026 11:24:10 PM
// Design Name: 
// Module Name: blink_025Hz
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module blink_025Hz(input CLOCK, output reg blink_25Hz = 0);
    reg [27:0] COUNT = 0;
    always @ (posedge CLOCK) begin
        COUNT <= (COUNT >= 199_999_999) ? 0 : COUNT+1;
        blink_25Hz <= (COUNT >= 199_999_999) ? ~blink_25Hz : blink_25Hz;
    end
endmodule
