`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 02/24/2026 02:21:41 PM
// Design Name: 
// Module Name: ass3_sim
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module ass3_sim();

    reg CLOCK;
    reg SW2, SW3, SW4;
    reg[4:0] BTN;
    
    wire [9:0] LEDS;
    wire [7:0] SEG;
    wire [3:0] AN;
    wire LED15;
    
    led_top_subtaskA dut(CLOCK, SW2, SW3, SW4, BTN, LEDS, SEG, AN, LED15);
    
    initial begin
        CLOCK = 0;
    end
    always begin
        #5; CLOCK = ~CLOCK;
    end
    
    initial begin
        SW2 = 0; SW3 = 0; SW4 = 0;
        BTN = 5'b00000;
        
        wait(dut.fa6.STATE == 1);
        
        #100;
                BTN[4] = 1; #50; // Hold for 5 cycles
                BTN[4] = 0; #100;
                
                // Step 2: BTN[1]
                BTN[1] = 1; #50;
                BTN[1] = 0; #100;
        
                // Step 3: BTN[2]
                BTN[2] = 1; #50;
                BTN[2] = 0; #100;
        
                // Step 4: BTN[3]
                BTN[3] = 1; #50;
                BTN[3] = 0; #100;
        
                // 4. Check for Unlock
                if (LED15) 
                    $display("SUCCESS: System Unlocked and LD15 is ON.");
                else 
                    $display("FAILURE: System still locked.");
        
                #1000;
                $finish;
            end
        endmodule