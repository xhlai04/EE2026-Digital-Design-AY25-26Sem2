`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 01/28/2026 03:57:46 PM
// Design Name: 
// Module Name: assignment_2
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module assignment_2(
    input SW0,
    input SW1,
    input SW2,
    input SW3,
    input SW4,
    input SW5,
    input SW6,
    input SW7,
    input SW8,
    input SW9,
    
    output LD0,
    output LD1,
    output LD2,
    output LD3,
    output LD4,
    output LD5,
    output LD6,
    output LD7,
    output LD8,
    output LD9,
    
    output AN0,
    output AN1,
    output AN2,
    output AN3,
    
    output SEG0,
    output SEG1,
    output SEG2,
    output SEG3,
    output SEG4,
    output SEG5,
    output SEG6
    );
    
    assign LD0 = SW0;
    assign LD1 = SW1;
    assign LD2 = SW2;
    assign LD3 = SW3;
    assign LD4 = SW4;
    assign LD5 = SW5;
    assign LD6 = SW6;
    assign LD7 = SW7;
    assign LD8 = SW8;
    assign LD9 = SW9;
    
    assign SEG0 = (SW1 | ~SW1);
    assign SEG2 = (SW1 | ~SW1);
    assign SEG4 = (SW1 | ~SW1);
    assign SEG6 = (SW1 | ~SW1);
    
    assign SEG1 = (SW1 & ~SW1);
    assign SEG3 = (SW1 & ~SW1);
    assign SEG5 = (SW1 & ~SW1);
    
    assign DP = (SW1 | ~SW1);
    
    assign AN0 = ~SW0 & SW1 & SW2 & SW3 & ~SW4 & SW5 & ~SW6 & ~SW7 & ~SW8 & ~SW9;
    assign AN1 = ~SW0 & SW1 & SW2 & SW3 & ~SW4 & SW5 & ~SW6 & ~SW7 & ~SW8 & ~SW9;
    assign AN2 = (SW1 & ~SW1); 
    assign AN3 = (SW1 & ~SW1);
   
endmodule
