`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 02/04/2026 09:31:30 PM
// Design Name: 
// Module Name: test_six_bit_adder
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module test_six_bit_adder(

    );
    
    //simulation inputs
    reg [5:0] A;
    reg [5:0] B;
    reg pb;
    
    //simulation outputs
    wire [3:0] an;
    wire [5:0] S;
    wire [7:0] seg;
    
    //instatntaion of module to be simulated
    digital_device dut(A, B, pb, an, S, seg);
    //stimuli
    initial begin
        A = 6'b110000; B=6'b001101; pb = 1'b0 ;#10;
        A = 6'b001110; B=6'b111010; pb = 1'b0 ;#10;
        A = 6'b101011; B=6'b110101; pb = 1'b0 ; #10;
        
        A = 6'b001010; B=6'b000100; pb = 1'b1; #10;
        A = 6'b010101; B=6'b001010; pb = 1'b1; #10;
        A = 6'b111111; B=6'b111111; pb = 1'b1; #10;
    end
endmodule
