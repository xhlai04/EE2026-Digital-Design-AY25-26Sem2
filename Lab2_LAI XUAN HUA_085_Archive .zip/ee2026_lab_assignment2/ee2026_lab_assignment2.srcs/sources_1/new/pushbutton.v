`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 02/04/2026 08:47:48 PM
// Design Name: 
// Module Name: pushbutton
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module pushbutton(
    input BTNR, 
    input [5:0]DR, 
    
    output [7:0] SEG, 
    output [3:0] AN, 
    output [5:0] AR, 
    output [5:0] S);
    
    assign SEG[7:0] = 8'b00100001;
    assign AR[5:0] = {1'b0 , DR[5:1]}; //DR/2
    assign S[5:0] = BTNR ? AR[5:0] : DR[5:0]; 
    assign AN[3:0] =  BTNR ? 4'b0001 : 4'b1110;
endmodule

