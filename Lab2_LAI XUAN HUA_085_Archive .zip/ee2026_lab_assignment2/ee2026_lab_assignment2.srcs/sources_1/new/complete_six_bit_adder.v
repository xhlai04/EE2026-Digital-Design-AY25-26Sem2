`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 02/04/2026 09:09:49 PM
// Design Name: 
// Module Name: complete_six_bit_adder
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module complete_six_bit_adder(input [5:0] A, input [5:0] B, output [5:0] DR);

wire C1;
wire COUT;

two_bit_parallel_adder fa1(A[1:0], B[1:0], 1'b0 , DR[1:0], C1);
four_bit_parallel_adder fa2(A[5:2], B[5:2], C1, DR[5:2], COUT);

endmodule
