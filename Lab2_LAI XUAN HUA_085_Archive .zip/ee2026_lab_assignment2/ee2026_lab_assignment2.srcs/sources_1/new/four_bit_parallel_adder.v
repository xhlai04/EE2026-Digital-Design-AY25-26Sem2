`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 02/04/2026 04:31:14 PM
// Design Name: 
// Module Name: four_bit_parallel_adder
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module four_bit_parallel_adder(input [3:0] A, input [3:0] B, input CIN,
                               output [3:0] S, COUT);
    wire C1, C2, C3;
    
    one_bit_adder fa0 (A[0], B[0], CIN, S[0], C1);
    one_bit_adder fa1 (A[1], B[1], C1, S[1], C2);
    one_bit_adder fa2 (A[2], B[2], C2, S[2], C3);
    one_bit_adder fa3 (A[3], B[3], C3, S[3], COUT);
endmodule
