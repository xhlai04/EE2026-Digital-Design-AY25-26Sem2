`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 02/04/2026 10:14:18 PM
// Design Name: 
// Module Name: digital_device
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module digital_device(
    input [5:0] A,
    input [5:0] B,
    input BTNR,
    output [3:0] AN,
    output [5:0] S,
    output [7:0] SEG);
    
    wire [5:0] DR;
    wire [5:0] AR;
    
    complete_six_bit_adder p1(A[5:0], B[5:0], DR[5:0]);
    pushbutton p2(BTNR, DR[5:0],SEG[7:0], AN[3:0], AR[5:0], S[5:0] );
endmodule
