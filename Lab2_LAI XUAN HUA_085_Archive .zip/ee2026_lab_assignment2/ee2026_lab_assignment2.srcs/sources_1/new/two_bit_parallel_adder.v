`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 02/04/2026 04:35:16 PM
// Design Name: 
// Module Name: two_bit_parallel_adder
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module two_bit_parallel_adder(input [1:0] A, [1:0] B, input CIN, output [1:0] S, COUT);
    wire C1;
    
    one_bit_adder fa0(A[0], B[0], CIN , S[0], C1);
    one_bit_adder fa1(A[1], B[1], C1, S[1], COUT);
endmodule
